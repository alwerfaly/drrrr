from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import requests
import os
import tempfile
import subprocess
import uuid
import json
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Configuration
DEEPSEEK_API_KEY = "sk-d5357f7a01864495820089eecdf816d3"
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"

# Create directories for temporary files and PDFs
TEMP_DIR = os.path.join(os.getcwd(), 'temp')
PDF_DIR = os.path.join(os.getcwd(), 'pdfs')
os.makedirs(TEMP_DIR, exist_ok=True)
os.makedirs(PDF_DIR, exist_ok=True)

class LatexCompiler:
    def __init__(self):
        self.temp_dir = TEMP_DIR
        self.pdf_dir = PDF_DIR
    
    def compile_latex(self, latex_code, title, user_id):
        """Compile LaTeX code to PDF"""
        try:
            # Create unique filename
            file_id = str(uuid.uuid4())
            tex_filename = f"{file_id}.tex"
            pdf_filename = f"{file_id}.pdf"
            
            tex_path = os.path.join(self.temp_dir, tex_filename)
            pdf_path = os.path.join(self.pdf_dir, pdf_filename)
            
            # Write LaTeX code to file
            with open(tex_path, 'w', encoding='utf-8') as f:
                f.write(latex_code)
            
            # Compile LaTeX to PDF using pdflatex
            compile_command = [
                'pdflatex',
                '-interaction=nonstopmode',
                '-output-directory', self.temp_dir,
                tex_path
            ]
            
            # Run compilation (may need multiple passes for references)
            for i in range(2):  # Run twice for proper references
                result = subprocess.run(
                    compile_command,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                
                if result.returncode != 0:
                    logger.error(f"LaTeX compilation failed: {result.stderr}")
                    # Try to extract useful error information
                    error_msg = self.extract_latex_error(result.stdout)
                    raise Exception(f"LaTeX compilation failed: {error_msg}")
            
            # Move PDF to final location
            temp_pdf_path = os.path.join(self.temp_dir, f"{file_id}.pdf")
            if os.path.exists(temp_pdf_path):
                os.rename(temp_pdf_path, pdf_path)
            else:
                raise Exception("PDF file was not generated")
            
            # Clean up temporary files
            self.cleanup_temp_files(file_id)
            
            # Return URL for PDF download
            pdf_url = f"/api/download-pdf/{pdf_filename}"
            return pdf_url
            
        except subprocess.TimeoutExpired:
            raise Exception("LaTeX compilation timed out")
        except Exception as e:
            logger.error(f"Error compiling LaTeX: {str(e)}")
            raise e
    
    def extract_latex_error(self, log_output):
        """Extract meaningful error message from LaTeX log"""
        lines = log_output.split('\n')
        error_lines = []
        
        for i, line in enumerate(lines):
            if '!' in line and 'error' in line.lower():
                error_lines.append(line)
                # Get next few lines for context
                for j in range(1, 4):
                    if i + j < len(lines):
                        error_lines.append(lines[i + j])
                break
        
        if error_lines:
            return ' '.join(error_lines)
        return "Unknown LaTeX error"
    
    def cleanup_temp_files(self, file_id):
        """Clean up temporary files"""
        extensions = ['.tex', '.aux', '.log', '.out', '.toc', '.bbl', '.blg']
        for ext in extensions:
            temp_file = os.path.join(self.temp_dir, f"{file_id}{ext}")
            if os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except:
                    pass

class DeepSeekAPI:
    def __init__(self, api_key):
        self.api_key = api_key
        self.api_url = DEEPSEEK_API_URL
    
    def generate_latex(self, prompt, max_tokens=4000):
        """Generate LaTeX code using DeepSeek API"""
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
        data = {
            'model': 'deepseek-chat',
            'messages': [
                {
                    'role': 'system',
                    'content': 'You are an expert LaTeX document generator. Generate complete, compilable LaTeX documents based on user requirements. Always include necessary packages and proper document structure. Return only the LaTeX code without any explanations or markdown formatting.'
                },
                {
                    'role': 'user',
                    'content': prompt
                }
            ],
            'max_tokens': max_tokens,
            'temperature': 0.7,
            'stream': False
        }
        
        try:
            response = requests.post(self.api_url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            latex_code = result['choices'][0]['message']['content'].strip()
            
            # Clean up the response to ensure it's pure LaTeX
            latex_code = self.clean_latex_response(latex_code)
            
            return latex_code
            
        except requests.exceptions.RequestException as e:
            logger.error(f"DeepSeek API error: {str(e)}")
            raise Exception(f"Failed to generate LaTeX: {str(e)}")
    
    def clean_latex_response(self, latex_code):
        """Clean up LaTeX response to remove any non-LaTeX content"""
        # Remove markdown code blocks if present
        if '```latex' in latex_code:
            latex_code = latex_code.split('```latex')[1].split('```')[0]
        elif '```' in latex_code:
            latex_code = latex_code.split('```')[1].split('```')[0]
        
        # Ensure document starts with \documentclass
        lines = latex_code.strip().split('\n')
        start_idx = 0
        for i, line in enumerate(lines):
            if line.strip().startswith('\\documentclass'):
                start_idx = i
                break
        
        return '\n'.join(lines[start_idx:]).strip()

# Initialize services
latex_compiler = LatexCompiler()
deepseek_api = DeepSeekAPI(DEEPSEEK_API_KEY)

@app.route('/')
def index():
    """Serve the main application"""
    return send_file('index.html')

@app.route('/<path:filename>')
def serve_static(filename):
    """Serve static files"""
    return send_file(filename)

@app.route('/api/generate-latex', methods=['POST'])
def generate_latex():
    """Generate LaTeX code using DeepSeek API"""
    try:
        data = request.get_json()
        prompt = data.get('prompt')
        max_tokens = data.get('maxTokens', 4000)
        user_id = data.get('userId')
        
        if not prompt:
            return jsonify({'error': 'Prompt is required'}), 400
        
        logger.info(f"Generating LaTeX for user {user_id}")
        
        # Generate LaTeX code
        latex_code = deepseek_api.generate_latex(prompt, max_tokens)
        
        return jsonify({
            'latex': latex_code,
            'success': True
        })
        
    except Exception as e:
        logger.error(f"Error generating LaTeX: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/compile-pdf', methods=['POST'])
def compile_pdf():
    """Compile LaTeX code to PDF"""
    try:
        data = request.get_json()
        latex_code = data.get('latex')
        title = data.get('title', 'Document')
        user_id = data.get('userId')
        
        if not latex_code:
            return jsonify({'error': 'LaTeX code is required'}), 400
        
        logger.info(f"Compiling PDF for user {user_id}")
        
        # Compile LaTeX to PDF
        pdf_url = latex_compiler.compile_latex(latex_code, title, user_id)
        
        return jsonify({
            'pdfUrl': pdf_url,
            'success': True
        })
        
    except Exception as e:
        logger.error(f"Error compiling PDF: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/download-pdf/<filename>')
def download_pdf(filename):
    """Download generated PDF"""
    try:
        pdf_path = os.path.join(PDF_DIR, filename)
        if not os.path.exists(pdf_path):
            return jsonify({'error': 'PDF not found'}), 404
        
        return send_file(
            pdf_path,
            as_attachment=True,
            download_name=filename,
            mimetype='application/pdf'
        )
        
    except Exception as e:
        logger.error(f"Error downloading PDF: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'services': {
            'deepseek_api': 'available',
            'latex_compiler': 'available'
        }
    })

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Check if LaTeX is installed
    try:
        result = subprocess.run(['pdflatex', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            logger.info("LaTeX installation found")
        else:
            logger.warning("LaTeX not found - PDF compilation will fail")
    except FileNotFoundError:
        logger.warning("LaTeX not found - installing...")
        # Note: In production, LaTeX should be pre-installed
    
    logger.info("Starting PDraft Flask server...")
    app.run(host='0.0.0.0', port=5000, debug=True)